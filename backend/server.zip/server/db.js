const mysql = require('mysql2/promise');
require('dotenv').config();

let pool;

async function initDB() {
  try {
    // 1. Create a temporary connection to ensure the database exists
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
    });

    console.log('Connected to MySQL server for initialization.');
    await connection.query(`CREATE DATABASE IF NOT EXISTS \`${process.env.DB_NAME}\``);
    await connection.end();

    // 2. Create the main pool WITH the database name
    pool = mysql.createPool({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });

    const poolConn = await pool.getConnection();
    console.log(`Connected to pool using database: ${process.env.DB_NAME}`);

    // 3. Initialize tables
    await poolConn.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        role ENUM('professor', 'student') NOT NULL,
        name VARCHAR(255) NOT NULL,
        student_id VARCHAR(50) DEFAULT NULL
      )
    `);

    await poolConn.query(`
      CREATE TABLE IF NOT EXISTS classes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        professor_id INT NOT NULL,
        schedule JSON DEFAULT NULL,
        FOREIGN KEY (professor_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);

    await poolConn.query(`
      CREATE TABLE IF NOT EXISTS sessions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        class_id INT NOT NULL,
        latitude DECIMAL(10, 8) DEFAULT 0,
        longitude DECIMAL(11, 8) DEFAULT 0,
        public_ip VARCHAR(45) NOT NULL,
        expires_at DATETIME NOT NULL,
        status ENUM('active', 'expired') DEFAULT 'active',
        FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
      )
    `);

    await poolConn.query(`
      CREATE TABLE IF NOT EXISTS attendance (
        id INT AUTO_INCREMENT PRIMARY KEY,
        session_id INT NOT NULL,
        student_id INT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        status ENUM('present', 'late', 'absent') DEFAULT 'present',
        FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);

    poolConn.release();
    console.log('Database and tables are ready.');
  } catch (err) {
    console.error('DATABASE INITIALIZATION ERROR:', err);
    process.exit(1);
  }
}

// Proxy to ensure pool is initialized before use
const poolProxy = {
  query: (...args) => {
    if (!pool) throw new Error('Database pool not initialized. Call initDB first.');
    return pool.query(...args);
  },
  getConnection: (...args) => {
    if (!pool) throw new Error('Database pool not initialized. Call initDB first.');
    return pool.getConnection(...args);
  }
};

module.exports = { pool: poolProxy, initDB };
