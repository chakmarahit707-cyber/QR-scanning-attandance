const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
require('dotenv').config();
const { pool, initDB } = require('./db');

const app = express();
app.set('trust proxy', true); // Correctly detect IP behind proxies
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5001;
const JWT_SECRET = process.env.JWT_SECRET;

// Middleware to authenticate JWT
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.status(401).json({ message: 'Authentication token required' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ message: 'Invalid or expired token' });
    req.user = user;
    next();
  });
};

// --- Auth Endpoints ---

app.post('/api/register', async (req, res) => {
  const { username, password, role, name, student_id } = req.body;
  try {
    const passwordHash = await bcrypt.hash(password, 10);
    await pool.query(
      'INSERT INTO users (username, password_hash, role, name, student_id) VALUES (?, ?, ?, ?, ?)',
      [username, passwordHash, role, name, role === 'student' ? student_id : null]
    );
    res.status(201).json({ message: 'User registered successfully' });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ message: 'Username already exists' });
    }
    res.status(500).json({ message: 'Error registering user', error: err.message });
  }
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const [rows] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);
    const user = rows[0];

    if (user && (await bcrypt.compare(password, user.password_hash))) {
      const token = jwt.sign(
        { id: user.id, username: user.username, role: user.role },
        JWT_SECRET,
        { expiresIn: '1d' }
      );
      res.json({ token, role: user.role, name: user.name });
    } else {
      res.status(401).json({ message: 'Invalid username or password' });
    }
  } catch (err) {
    res.status(500).json({ message: 'Error logging in', error: err.message });
  }
});

// --- Professor Endpoints ---

app.post('/api/classes', authenticateToken, async (req, res) => {
  if (req.user.role !== 'professor') return res.status(403).json({ message: 'Only professors can create classes' });
  const { name, schedule } = req.body;
  try {
    await pool.query(
      'INSERT INTO classes (name, professor_id, schedule) VALUES (?, ?, ?)',
      [name, req.user.id, JSON.stringify(schedule)]
    );
    res.status(201).json({ message: 'Class created successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error creating class', error: err.message });
  }
});

app.get('/api/classes', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM classes WHERE professor_id = ?', [req.user.id]);
    res.json(rows);
  } catch (err) {
    console.error('Fetch Classes Error:', err);
    res.status(500).json({ message: 'Error fetching classes', details: err.message });
  }
});

app.delete('/api/classes/:id', authenticateToken, async (req, res) => {
  if (req.user.role !== 'professor') return res.status(403).json({ message: 'Only professors can delete classes' });
  const { id } = req.params;
  try {
    const [result] = await pool.query('DELETE FROM classes WHERE id = ? AND professor_id = ?', [id, req.user.id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Class not found or unauthorized' });
    res.json({ message: 'Class deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error deleting class', details: err.message });
  }
});

// Create an attendance session
app.post('/api/sessions', authenticateToken, async (req, res) => {
  if (req.user.role !== 'professor') return res.status(403).json({ message: 'Only professors can start sessions' });
  const { class_id, duration_minutes } = req.body;
  
  if (!class_id || !duration_minutes) {
    return res.status(400).json({ message: 'Class ID and duration are required' });
  }

  const latitude = 0;
  const longitude = 0;
  // Handle IP detection more robustly
  let public_ip = req.ip;
  if (public_ip.includes('::ffff:')) {
    public_ip = public_ip.split('::ffff:')[1];
  }
  if (public_ip === '::1') public_ip = '127.0.0.1';

  // Calculate expiry in MySQL format (YYYY-MM-DD HH:MM:SS)
  const expiryDate = new Date(Date.now() + duration_minutes * 60000);
  const mysqlExpiry = expiryDate.toISOString().slice(0, 19).replace('T', ' ');

  try {
    console.log('[Session] Creating session for class:', class_id);
    const [result] = await pool.query(
      'INSERT INTO sessions (class_id, latitude, longitude, public_ip, expires_at) VALUES (?, ?, ?, ?, ?)',
      [class_id, latitude, longitude, public_ip, mysqlExpiry]
    );
    console.log('[Session] Created ID:', result.insertId);
    res.status(201).json({ session_id: result.insertId, expires_at: expiryDate });
  } catch (err) {
    console.error('CRITICAL SESSION ERROR:', err);
    res.status(500).json({ 
      message: 'Database error while starting session', 
      details: err.message 
    });
  }
});

// --- Student Endpoints ---

app.post('/api/attendance/submit', authenticateToken, async (req, res) => {
  if (req.user.role !== 'student') return res.status(403).json({ message: 'Only students can submit attendance' });
  const { session_id } = req.body;
  
  let student_ip = req.ip;
  if (student_ip.includes('::ffff:')) {
    student_ip = student_ip.split('::ffff:')[1];
  }
  if (student_ip === '::1') student_ip = '127.0.0.1';

  try {
    const [sessions] = await pool.query('SELECT * FROM sessions WHERE id = ?', [session_id]);
    const session = sessions[0];

    if (!session) return res.status(404).json({ message: 'Session not found' });
    
    // Check expiry using server time comparison
    console.log("Session: ", Session);
    console.log("Current Time: ", new Date());
    if (new Date() > new Date(session.expires_at)) {
      return res.status(400).json({ message: 'Session has expired' });
    }
    console.log(`[Attendance] Attempt by ${req.user.username}`);
    console.log(`[Attendance] Student IP: ${student_ip}, Session IP: ${session.public_ip}`);

    // IP Check
    if (student_ip !== session.public_ip) {
      console.warn(`[Attendance] IP mismatch for ${req.user.username}`);
      return res.status(403).json({ message: 'Network mismatch. Must be on the same WiFi as the professor.' });
    }

    // Check if already submitted
    const [existing] = await pool.query('SELECT * FROM attendance WHERE session_id = ? AND student_id = ?', [session_id, req.user.id]);
    if (existing.length > 0) return res.status(400).json({ message: 'Attendance already marked for this session' });

    await pool.query(
      'INSERT INTO attendance (session_id, student_id, status) VALUES (?, ?, ?)',
      [session_id, req.user.id, 'present']
    );

    res.status(201).json({ message: 'Attendance marked successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error submitting attendance', error: err.message });
  }
});

app.get('/api/attendance-report', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT 
        a.id, 
        u.name as student_name, 
        u.student_id, 
        c.name as class_name, 
        a.timestamp, 
        a.status
      FROM attendance a
      JOIN users u ON a.student_id = u.id
      JOIN sessions s ON a.session_id = s.id
      JOIN classes c ON s.class_id = c.id
      ORDER BY a.timestamp DESC
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching attendance report', error: err.message });
  }
});

// Start Server
initDB().then(() => {
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT} (reachable at http://YOUR_IP:${PORT})`);
  });
});
