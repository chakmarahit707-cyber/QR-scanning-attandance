import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import './App.css';
import Login from './components/Login';
import Register from './components/Register';
import ProfessorDashboard from './components/ProfessorDashboard';
import StudentScanner from './components/StudentScanner';
import AttendanceVerification from './components/AttendanceVerification';
import AttendanceSheet from './components/AttendanceSheet';

interface PrivateRouteProps {
  children: React.ReactNode;
  role: 'professor' | 'student';
}

const PrivateRoute: React.FC<PrivateRouteProps> = ({ children, role }) => {
  const token = localStorage.getItem('token');
  const userRole = localStorage.getItem('role');

  if (!token) return <Navigate to="/login" />;
  if (userRole !== role) return <Navigate to="/login" />;
  
  return <>{children}</>;
};

function App() {
  const handleLogout = () => {
    localStorage.clear();
    window.location.href = '/login';
  };

  const name = localStorage.getItem('name') || 'User';
  const token = localStorage.getItem('token');

  return (
    <Router>
      {token && (
        <nav>
          <div>QR Attendance</div>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <Link to="/attendance-sheet" style={{ marginRight: '15px' }}>Attendance Sheet</Link>
            {localStorage.getItem('role') === 'professor' ? (
              <Link to="/professor" style={{ marginRight: '15px' }}>Dashboard</Link>
            ) : (
              <Link to="/student" style={{ marginRight: '15px' }}>Scanner</Link>
            )}
            <span>Welcome, {name}</span>
            <button onClick={handleLogout} style={{width: 'auto', marginLeft: '10px', padding: '5px 10px'}}>Logout</button>
          </div>
        </nav>
      )}
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route 
          path="/attendance-sheet" 
          element={
            <PrivateRoute role={localStorage.getItem('role') as any}>
              <AttendanceSheet />
            </PrivateRoute>
          } 
        />
        <Route 
          path="/professor" 
          element={
            <PrivateRoute role="professor">
              <ProfessorDashboard />
            </PrivateRoute>
          } 
        />
        <Route 
          path="/student" 
          element={
            <PrivateRoute role="student">
              <StudentScanner />
            </PrivateRoute>
          } 
        />
        <Route 
          path="/verify/:sessionId" 
          element={
            <PrivateRoute role="student">
              <AttendanceVerification />
            </PrivateRoute>
          } 
        />
        <Route path="/" element={<Navigate to="/login" />} />
      </Routes>
    </Router>
  );
}

export default App;
