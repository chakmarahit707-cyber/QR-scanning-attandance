import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { QRCodeSVG } from 'qrcode.react';
import API_BASE_URL from '../config';

interface ClassData {
  id: number;
  name: string;
  schedule: any;
}

interface ActiveSession {
  session_id: number;
  expires_at: string;
}

const ProfessorDashboard: React.FC = () => {
  const [classes, setClasses] = useState<ClassData[]>([]);
  const [className, setClassName] = useState('');
  const [durationMinutes, setDurationMinutes] = useState(5);
  const [activeSession, setActiveSession] = useState<ActiveSession | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchClasses();
  }, []);

  const fetchClasses = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get(`${API_BASE_URL}/api/classes`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setClasses(res.data);
    } catch (err: any) {
      const msg = err.response?.data?.details || err.response?.data?.message || 'Failed to fetch classes';
      setError(msg);
    }
  };

  const deleteClass = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this class? All session data will be lost.')) return;
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`${API_BASE_URL}/api/classes/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchClasses();
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to delete class');
    }
  };

  const createClass = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post(`${API_BASE_URL}/api/classes`, { name: className, schedule: {} }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setClassName('');
      fetchClasses();
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to create class');
    }
  };

  const startSession = async (classId: number) => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.post(`${API_BASE_URL}/api/sessions`, {
        class_id: classId,
        duration_minutes: durationMinutes
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setActiveSession(res.data);
      // Auto-expire session locally after timer
      setTimeout(() => setActiveSession(null), durationMinutes * 60000);
    } catch (err: any) {
      console.error('Start Session Error:', err);
      const msg = err.response?.data?.details || err.response?.data?.message || 'Failed to start session';
      setError(msg);
    }
  };

  return (
    <div className="container">
      <div className="card">
        <h2>Professor Dashboard</h2>
        {error && <div className="error">{error}</div>}
        
        <form onSubmit={createClass} style={{display: 'flex', gap: '10px'}}>
          <input 
            type="text" 
            placeholder="New Class Name" 
            value={className} 
            onChange={(e) => setClassName(e.target.value)} 
            required 
          />
          <button type="submit" style={{width: 'auto'}}>Add</button>
        </form>

        <div style={{marginTop: '20px'}}>
          <label>Session Duration (minutes):</label>
          <input 
            type="number" 
            value={durationMinutes} 
            onChange={(e) => setDurationMinutes(parseInt(e.target.value) || 1)}
            min="1"
            max="60"
            style={{width: '100px', marginLeft: '10px'}}
          />
        </div>

        <div style={{marginTop: '20px'}}>
          <h3>Your Classes</h3>
          {classes.map(c => (
            <div key={c.id} className="class-item">
              <span>{c.name}</span>
              <button onClick={() => startSession(c.id)} style={{width: 'auto', padding: '5px 15px'}}>Generate QR</button>
            </div>
          ))}
        </div>
      </div>

      {activeSession && (
        <div className="card qr-container">
          <h3>Scan to mark Attendance</h3>
          <QRCodeSVG value={`${window.location.origin}/verify/${activeSession.session_id}`} size={256} />
          <p>Valid until: {new Date(activeSession.expires_at).toLocaleTimeString()}</p>
          <button onClick={() => setActiveSession(null)} className="secondary">Close QR</button>
        </div>
      )}
    </div>
  );
};

export default ProfessorDashboard;
