import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import API_BASE_URL from '../config';

const AttendanceVerification: React.FC = () => {
  const { sessionId } = useParams<{ sessionId: string }>();
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  const studentName = localStorage.getItem('name');

  const handleConfirm = async () => {
    setIsSubmitting(true);
    setError('');
    
    try {
      const token = localStorage.getItem('token');
      const res = await axios.post(`${API_BASE_URL}/api/attendance/submit`, {
        session_id: sessionId
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setSuccess(res.data.message);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to mark attendance');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (success) {
    return (
      <div className="container">
        <div className="card success">
          <h2>Success!</h2>
          <p>{success}</p>
          <button onClick={() => navigate('/student')}>Go Back</button>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="card">
        <h2>Verify Attendance</h2>
        <p>You are about to mark attendance for the following student:</p>
        
        <div style={{ background: '#f9f9f9', padding: '15px', borderRadius: '4px', margin: '20px 0' }}>
          <p><strong>Name:</strong> {studentName}</p>
          <p><strong>Session ID:</strong> {sessionId}</p>
        </div>

        {error && <div className="error">{error}</div>}

        <button 
          onClick={handleConfirm} 
          disabled={isSubmitting}
          style={{ background: isSubmitting ? '#ccc' : '#27ae60' }}
        >
          {isSubmitting ? 'Submitting...' : 'Confirm My Attendance'}
        </button>
        
        <button onClick={() => navigate('/student')} className="secondary" style={{ marginTop: '10px' }}>
          Cancel
        </button>
      </div>
    </div>
  );
};

export default AttendanceVerification;
