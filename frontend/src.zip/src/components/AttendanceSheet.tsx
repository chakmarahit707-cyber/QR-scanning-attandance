import React, { useState, useEffect } from 'react';
import axios from 'axios';
import API_BASE_URL from '../config';

interface AttendanceRecord {
  id: number;
  student_name: string;
  student_id: string;
  class_name: string;
  timestamp: string;
  status: string;
}

const AttendanceSheet: React.FC = () => {
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchAttendance();
  }, []);

  const fetchAttendance = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get(`${API_BASE_URL}/api/attendance-report`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setRecords(res.data);
    } catch (err) {
      setError('Failed to fetch attendance records');
    }
  };

  return (
    <div className="container">
      <div className="card">
        <h2>Attendance Sheet</h2>
        {error && <div className="error">{error}</div>}
        
        <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '20px' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #ddd', textAlign: 'left' }}>
              <th style={{ padding: '10px' }}>Student Name</th>
              <th style={{ padding: '10px' }}>Student ID</th>
              <th style={{ padding: '10px' }}>Class</th>
              <th style={{ padding: '10px' }}>Time</th>
              <th style={{ padding: '10px' }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {records.map(record => (
              <tr key={record.id} style={{ borderBottom: '1px solid #eee' }}>
                <td style={{ padding: '10px' }}>{record.student_name}</td>
                <td style={{ padding: '10px' }}>{record.student_id}</td>
                <td style={{ padding: '10px' }}>{record.class_name}</td>
                <td style={{ padding: '10px' }}>{new Date(record.timestamp).toLocaleString()}</td>
                <td style={{ padding: '10px' }}>
                  <span style={{ 
                    padding: '4px 8px', 
                    borderRadius: '4px', 
                    background: record.status === 'present' ? '#d4efdf' : '#fadbd8',
                    color: record.status === 'present' ? '#27ae60' : '#e74c3c'
                  }}>
                    {record.status}
                  </span>
                </td>
              </tr>
            ))}
            {records.length === 0 && !error && (
              <tr>
                <td colSpan={5} style={{ padding: '20px', textAlign: 'center' }}>No attendance records found.</td>
              </tr>
            )}
          </tbody>
        </table>
        <button onClick={fetchAttendance} style={{ marginTop: '20px', width: 'auto' }}>Refresh</button>
      </div>
    </div>
  );
};

export default AttendanceSheet;
