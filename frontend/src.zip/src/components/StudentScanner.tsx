import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { useNavigate } from 'react-router-dom';
import API_BASE_URL from '../config';

const StudentScanner: React.FC = () => {
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isScanning, setIsScanning] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const scanner = new Html5QrcodeScanner("reader", { 
      fps: 10, 
      qrbox: { width: 250, height: 250 },
      aspectRatio: 1.0,
      rememberLastUsedCamera: true,
      supportedScanTypes: [0] // 0 = QR Code
    }, false);
    
    scanner.render(async (decodedText: string) => {
      // Check if it's a URL and extract the ID, or if it's just the ID/JSON
      let sessionId = '';
      if (decodedText.includes('/verify/')) {
        sessionId = decodedText.split('/verify/')[1];
      } else {
        try {
          const data = JSON.parse(decodedText);
          sessionId = data.sessionId;
        } catch(e) {
          sessionId = decodedText;
        }
      }

      if (sessionId) {
        scanner.clear().then(() => {
          navigate(`/verify/${sessionId}`);
        }).catch(err => {
          navigate(`/verify/${sessionId}`);
        });
      }
    }, (err: any) => {
      // ignore errors
    });

    return () => {
      scanner.clear().catch(e => console.warn("Scanner cleanup warning:", e));
    };
  }, [navigate]);

  return (
    <div className="container">
      <div className="card">
        <h2>Student Attendance Scanner</h2>
        {error && <div className="error">{error}</div>}
        {success && <div className="success">{success}</div>}
        {isProcessing && <div className="info" style={{padding: '10px', background: '#e1f5fe', color: '#01579b', borderRadius: '4px', marginBottom: '10px'}}>Processing attendance... Please wait.</div>}
        
        <div id="reader" style={{ width: '100%', display: isScanning ? 'block' : 'none' }}></div>
        
        {!isScanning && !success && (
          <button onClick={() => window.location.reload()}>Try Scanning Again</button>
        )}
      </div>
    </div>
  );
};

export default StudentScanner;
